const printRectangle = require('../src/lib.js').printRectangle;
const printTriangle = require('../src/lib.js').printTriangle;
const returnSecondArgument = require('../src/lib.js').returnSecondArgument;
const getPattern = require('../src/lib.js').getPattern;
const assert = require('assert');

const testOfReturnSecondArgment = function(){
  console.log("test of returnSecondArgument");
  let expectedOP = "rectangle";
  assert.strictEqual(returnSecondArgument("-s","rectangle"),expectedOP);
  expectedOP = false;
  assert.strictEqual(returnSecondArgument("s","rectangle"),expectedOP);
};

const testOfPrintRectangle = function(){
  console.log("test of printRectangle");
  const expectedOP = "******\n******\n******\n";
  assert.strictEqual(printRectangle(),expectedOP);
};

const testOfPrintTriangle = function(){
  console.log("test of printTriangle");
  const expectedOP = "*\n**\n***\n****\n*****\n******\n";
  assert.strictEqual(printTriangle(),expectedOP);
};

const testOfGetPattern = function(){
  console.log("test of getPattern");
  let expectedOP = "******\n******\n******\n";
  assert.strictEqual(getPattern("rectangle"),expectedOP);
  expectedOP = "*\n**\n***\n****\n*****\n******\n";
  assert.strictEqual(getPattern("triangle"),expectedOP);
  expectedOP = "";
  assert.strictEqual(getPattern("triad"),expectedOP);
};

const runTest = function(){
  testOfPrintTriangle();
  testOfPrintRectangle();
  testOfReturnSecondArgment();
  testOfGetPattern();
};

runTest();
